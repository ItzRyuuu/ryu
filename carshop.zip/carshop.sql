/*
SQLyog Enterprise - MySQL GUI v8.18 
MySQL - 5.7.36 : Database - carshop
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`carshop` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `carshop`;

/*Table structure for table `tbladmin` */

DROP TABLE IF EXISTS `tbladmin`;

CREATE TABLE `tbladmin` (
  `adminID` int(11) NOT NULL AUTO_INCREMENT,
  `fullname` varchar(50) DEFAULT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`adminID`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

/*Data for the table `tbladmin` */

insert  into `tbladmin`(`adminID`,`fullname`,`username`,`password`) values (1,'Bun Tong','Tong','202cb962ac59075b964b07152d234b70'),(2,'Tho Mengfong','Fong','202cb962ac59075b964b07152d234b70'),(3,'Ly David','David','202cb962ac59075b964b07152d234b70');

/*Table structure for table `tblorder` */

DROP TABLE IF EXISTS `tblorder`;

CREATE TABLE `tblorder` (
  `orderid` int(11) NOT NULL AUTO_INCREMENT,
  `orderdate` date DEFAULT NULL,
  `fullname` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `address` varchar(150) DEFAULT NULL,
  `productID` int(11) NOT NULL,
  PRIMARY KEY (`orderid`,`productID`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

/*Data for the table `tblorder` */

insert  into `tblorder`(`orderid`,`orderdate`,`fullname`,`email`,`phone`,`city`,`address`,`productID`) values (1,'2024-06-04','Keo Veasna','veasna@gmail.com','096123456','Battambang','Battambang , Prek MohaTep',3),(2,'2024-06-04','Keo Veasna','veasna@gmail.com','096123456','Battambang','Battambang , Prek MohaTep',4),(3,'2024-06-04','Preap Sovath','preapsovath@gmail.com','012456125','Phnom Penh','Phnom Penh , Khan Mean Chey',2),(7,'2024-06-05','Sok Sopheap','sopheap@gmail.com','010999299','Siemreap','Siemreap , Sangkat Svay Dangkum',1),(5,'2024-06-04','Preap Sovath','preapsovath@gmail.com','012456125','Phnom Penh','Phnom Penh , Khan Mean Chey',3),(6,'2024-06-04','Keo Veasna','veasna@gmail.com','012345678','Battambang','Battambang , Prek MohaTep',2);

/*Table structure for table `tblorderproduct` */

DROP TABLE IF EXISTS `tblorderproduct`;

CREATE TABLE `tblorderproduct` (
  `orderid` int(11) NOT NULL,
  `productID` int(11) NOT NULL,
  `model` varchar(50) DEFAULT NULL,
  `qty` int(11) DEFAULT NULL,
  `price` float DEFAULT NULL,
  `userID` int(11) NOT NULL,
  PRIMARY KEY (`orderid`,`productID`,`userID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

/*Data for the table `tblorderproduct` */

insert  into `tblorderproduct`(`orderid`,`productID`,`model`,`qty`,`price`,`userID`) values (1,3,'Ford Raptor',1,55150,1),(2,4,'Audi R8',1,137281,1),(3,2,'BMW M5',1,107900,2),(7,1,'GTR R35',1,110330,3),(5,3,'Ford Raptor',1,55150,2),(6,2,'BMW M5',1,107900,1);

/*Table structure for table `tblproduct` */

DROP TABLE IF EXISTS `tblproduct`;

CREATE TABLE `tblproduct` (
  `productID` int(11) NOT NULL AUTO_INCREMENT,
  `model` varchar(100) DEFAULT NULL,
  `make` varchar(100) DEFAULT NULL,
  `year` varchar(50) DEFAULT NULL,
  `price` float DEFAULT NULL,
  `qty` int(11) DEFAULT NULL,
  `image` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`productID`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

/*Data for the table `tblproduct` */

insert  into `tblproduct`(`productID`,`model`,`make`,`year`,`price`,`qty`,`image`) values (1,'GTR R35','Nissan','2014',110330,1,'1.jpg'),(2,'BMW M5','BMW M','2023',107900,2,'2.jpg'),(3,'Ford Raptor','Ford','2020',55150,4,'3.jpg'),(4,'Audi R8','Audi','2016',137281,3,'4.jpg');

/*Table structure for table `tbluser` */

DROP TABLE IF EXISTS `tbluser`;

CREATE TABLE `tbluser` (
  `userID` int(11) NOT NULL AUTO_INCREMENT,
  `fullname` varchar(50) DEFAULT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(150) DEFAULT NULL,
  `gender` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`userID`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

/*Data for the table `tbluser` */

insert  into `tbluser`(`userID`,`fullname`,`username`,`password`,`gender`,`email`,`phone`) values (1,'Keo Veasna','veasna','202cb962ac59075b964b07152d234b70','Male','veasna@gmail.com','0123456789'),(2,'Preap Sovath','Sovath','202cb962ac59075b964b07152d234b70','Male','preapsovath@gmail.com','0124561255'),(3,'Sok Pheap','pheap','202cb962ac59075b964b07152d234b70','Female','sokpheap@gmail.com','0923456733');

/*Table structure for table `vstatistic` */

DROP TABLE IF EXISTS `vstatistic`;

/*!50001 DROP VIEW IF EXISTS `vstatistic` */;
/*!50001 DROP TABLE IF EXISTS `vstatistic` */;

/*!50001 CREATE TABLE  `vstatistic`(
 `model` varchar(100) ,
 `Quantity` decimal(32,0) ,
 `Total` double 
)*/;

/*View structure for view vstatistic */

/*!50001 DROP TABLE IF EXISTS `vstatistic` */;
/*!50001 DROP VIEW IF EXISTS `vstatistic` */;

/*!50001 CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vstatistic` AS select `a`.`model` AS `model`,sum(`b`.`qty`) AS `Quantity`,sum(`b`.`price`) AS `Total` from (`tblproduct` `a` left join `tblorderproduct` `b` on((`a`.`productID` = `b`.`productID`))) group by `a`.`model` */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
