<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>shop</title>
</head>

<style>
    h1 {
        font-weight: bold;
        margin-top: 3em;
        font-family: monospace;
        text-align: center;
        font-weight: bold;
        font-size: 30px;
    }

    .fieldset {
        margin-top: 1em;
        width: 100%;
        height: 12vh;
        padding-top: 1em;

    }

    legend {
        text-align: center;
    }

    .text {
        height: 35px;
        width: 250px;
        font-size: 17px;
        text-align: center;
        font-family: monospace;
    }

    .label1 {

        height: 25px;
        width: 150px;
        font-size: 17px;
        text-align: center;
        font-family: monospace;

    }

    .btn-search {

        background-color: #10439F;
        width: 80px;
        border-radius: 8px;
        color: white;
        padding: 6px 11px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 18px;
        cursor: pointer;
        font-family: monospace;
        border: none;
        margin: 2px;

    }

    .btn-search:hover {
        background-color: #4681f4;

    }

    .drop {
        font-size: 17px;
        text-align: center;
        width: 150px;
        height: 34px;
        font-family: monospace;
        margin: 3px;
    }

    main {
        max-width: 1500px;
        width: 95%;
        margin: 30px auto;
        display: flex;
        flex-wrap: wrap;
        justify-content: space-between;
        margin: auto;
        margin-top: 1em;
    }

    main .card {
        max-width: 295px;
        flex: 1 1 210px;
        text-align: center;
        height: 425px;
        border: 1px solid lightgray;
        margin: 15px;
        border-radius: 15px;
    }

    main .card .image {
        height: 50%;
        margin-bottom: 20px;
        border-radius: 15px;
    }

    main .card .image img {
        border-radius: 15px;
        width: 100%;
        height: 100%;
        object-fit: cover;
    }

    main .card .caption {

        padding-left: 1em;
        text-align: left;
        line-height: 2.9em;
        height: 25%;
    }

    main .card .caption p {
        font-size: 1.2rem;
        color: black;
        text-align: ;
    }

    .btn-order {

        background-color: #40A578;
        border-radius: 8px;
        color: white;
        padding: 6px 17px;
        text-decoration: none;
        font-size: 16.2px;
        font-family: Arial;
        cursor: pointer;
        margin-left: 11.7em;
    }
</style>

<body>
    <div>

        <h1>Car List</h1>
        <?php $text = isset($_POST['txtsearch']) ? $_POST['txtsearch'] : null; ?>
        <?php $filterby = isset($_POST['filterby']) ? $_POST['filterby'] : null; ?>
        <div class="fieldset" align="center">
            <legend>Search</legend>
            <form method="post">
                <select class="drop" name="txtfield">
                    <option value="1">Model</option>
                </select>
                <input class="text" type="text" name="txtsearch" value="<?php echo ($text) ?>">
                <input class="btn-search" type="submit" name="btnsearch" value="Search" class='button'>
                <input class="btn-search" type="submit" name="btnreset" value="Reset" class='button button5'>

            </form>

        </div>
        <?php
        require ("db.php");
        $sql = "SELECT * FROM tblproduct";
        if (isset($_POST["btnsearch"])) {
            $field = $_POST["txtfield"];
            switch ($field) {
                case '1':
                    $sql .= " WHERE model LIKE CONCAT('%', ?, '%')";
                    break;
            }
            $stmt = $conn->prepare($sql);
            $stmt->bind_param('s', $text);
        } else {
            $stmt = $conn->prepare($sql);
        }
        $stmt->execute();
        $result = $stmt->get_result();
        ?>
        <main>
            <?php

            while ($row = $result->fetch_assoc()) {
                ?>
                <div class="card">
                    <div class="image">
                        <img src="<?php echo ("Images/" . $row["image"]) ?>" alt="">
                    </div>
                    <div class="caption">
                        <p class="product_name"><b>Model : <?php echo $row["model"]; ?></b></p>
                        <p style="color:red;" class="price"><b>Price : $<?php echo $row["price"]; ?></b></p>
                        <p style="color:green;" class="qty"><b>Stock : <?php echo $row["qty"]; ?></del></b></p>
                        <?php
                        echo ("<a href='order.php?productID=" . $row["productID"] . "&model=" . $row["model"] . "&qty=" . $row["qty"] . "&price=" .
                            $row["price"] . "' class='btn-order'>Order </a>");
                        ?>
                    </div>
                </div>
                <?php
            }
            ?>
        </main>
    </div>
    <?php
    include ("headeruser.php");
    ?>

</body>

</html>