<?php
ob_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<style>
    body {
        background-image: url("15691.jpg");
        background-size: cover;
        background-position: center;
        background-color: #f8f8f8;
        background-attachment: fixed;
    }

    label {
        font-family: monospace;
        font-size: 17px;
    }

    .drop {
        height: 40px;
        width: 305px;
        font-size: 20px;
        text-align: center;
        font-family: monospace;
        margin-bottom: 5px;
        margin-top: 5px;
        border-radius: 8px;
        background-color: transparent;
        border-width: 2px;
    }

    .text {
        height: 35px;
        width: 300px;
        font-size: 20px;
        text-align: center;
        font-family: monospace;
        margin-bottom: 5px;
        margin-top: 5px;
        border-radius: 10px;
        background-color: transparent;
    }

    h1 {
        margin-bottom: 10px;
        font-size: 40px;
        font-family: Courier;
        color: black;
        text-align: center;
        top: 0px;
    }

    div {

        text-align: left;
        style=font-family: Courier New;
        font-size: 15px;
        padding-top: 10px;
        color: black;
    }

    .submitbutton {

        background-color: #00b4d8;
        /* background-color: #0D47A1; */
        color: white;
        border: 1px;
        cursor: pointer;
        text-align: center;
        width: 60%;
        height: 35px;
        border-radius: 10px;
        margin-top: 1em;
        transition: 10s;

    }

    table {
        font-size: 20px;
        width: 60px;
        height: 20px;
    }

    ::placeholder {

        color: grey;
        font-size: 15px;
    }
</style>

<body>
    <div class="background">
        <div class="shape"></div>
        <div class="shape"></div>
    </div>
    <h1>Sign Up</h1>
    <div class="form">
        <form method="post">
            <table align="center" border="0">
                <td>
                    <label for="fullname">Fullname</label><br>
                </td>
                <tr>
                    <td>
                        <input class="text" type="text" placeholder="Enter Fullname" id="fullname" name="fullname"
                            required><br>
                    </td>
                </tr>
                <td>
                    <label for="username">Username</label><br>
                </td>
                <tr>
                    <td>
                        <input class="text" type="text" placeholder="Enter Username" id="username" name="username"
                            required><br>
                    </td>
                </tr>
                <td>
                    <label for="password">Password</label><br>
                </td>
                <tr>
                    <td>
                        <input class="text" type="text" placeholder="Enter Password" id="password" name="password"
                            required><br>
                    </td>
                </tr>
                <td>
                    <label for="gender">Gender</label><br>
                </td>
                <tr>
                    <td>
                        <select class="drop" name="gender">
                            <option>Male</option>
                            <option>Female</option>
                        </select>
                    </td>
                </tr>
                <td>
                    <label for="email">Email</label><br>
                </td>
                <tr>
                    <td>
                        <input class="text" type="text" placeholder="Enter Email" id="email" name="email" required><br>
                    </td>
                </tr>
                <td>
                    <label for="phone">Phone</label><br>
                </td>
                <tr>
                    <td>
                        <input class="text" type="text" placeholder="Enter PhoneNumber" id="phone" name="phone"
                            required><br>
                    </td>
                </tr>
                <tr>
                    <td align="center">
                        <button class="submitbutton" name="submit">Sign Up</button>
                    </td>
                </tr>
            </table>
        </form>
        <?php
        ob_start();
        if (isset($_POST["submit"])) {
            require ("db.php");
            $fullname = $_POST['fullname'];
            $username = $_POST['username'];
            $pass = $_POST['password'];
            $gender = $_POST['gender'];
            $email = $_POST['email'];
            $phone = $_POST['phone'];

            $password = md5($pass);

            $sql = "INSERT INTO tbluser(fullname,username, password , gender , email , phone) VALUES(?,?,?,?,?,?);";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ssssss", $fullname, $username, $password, $gender, $email, $phone);
            if ($stmt->execute() == true) {
                header("Location:login.php");
            } else {
                echo "Error: " . $sql . "<br>" . $conn->error;
            }
        }

        ?>
    </div>
</body>

</html>
<?php
ob_end_flush();
?>