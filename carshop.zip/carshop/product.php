<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title></title>

</head>

<style>
    h1 {
        margin-top: 3.5em;
        font-family: monospace;
        text-align: center;
        font-weight: bold;
        font-size: 30px;
    }

    .fieldset {
        margin-top: 1em;
        width: 100%;
        height: 12vh;
        padding-top: 1em;

    }

    legend {
        text-align: center;
    }

    .text {
        height: 35px;
        width: 250px;
        font-size: 17px;
        text-align: center;
        font-family: monospace;
    }

    .label1 {

        height: 25px;
        width: 150px;
        font-size: 17px;
        text-align: center;
        font-family: monospace;

    }

    .btn-search {

        background-color: #10439F;
        width: 80px;
        border-radius: 8px;
        color: white;
        padding: 6px 11px;
        text-align: center;
        display: inline-block;
        font-size: 18px;
        cursor: pointer;
        font-family: monospace;
        border: none;
        margin: 2px;

    }

    .btn-search:hover {
        background-color: #4681f4;

    }

    .div-table {

        text-align: center;
        padding-top: 2em;
        width: 100%;
        display: table;
        position: relative;
    }

    .table {

        margin-left: 8em;
        width: 85%;
        height: 140px;
        font-size: 15px;
        border-collapse: collapse;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        position: absolute;

    }

    th {

        font-family: "Courier New", Courier, monospace;
        letter-spacing: 1px;
        font-size: 20px;
        /* background-color: #5DEBD7; */
        color: black;
        height: 50px;
        padding-bottom: 10px;
        font-weight: bold;
    }

    td {
        width: 100em;
        border-top: 1px solid grey
    }

    .btn-delete {
        background-color: #FF204E;
        width: 80px;
        height: 30px;
        border-radius: 8px;
        color: white;
        padding: 4px 14px;
        display: inline-block;
        font-size: 17px;
        margin: 4px 3px;
        cursor: pointer;
        font-family: monospace;
        margin-bottom: 8px;
    }

    .btn-delete:hover {
        background-color: #FC4100;
    }

    .btn-add {

        background-color: #389f0a;
        border-radius: 8px;
        color: white;
        padding: 8px 15px;
        text-decoration: none;
        font-size: 19px;
        cursor: pointer;
        font-family: monospace;
        margin-top: 12em;
        margin-right: 1.3em;
    }

    .btn-add:hover {
        background-color: #2d8208;
    }

    .btn-edit {

        height: 30px;
        margin-top: 8px;
        background-color: #5356FF;
        width: 80px;
        border-radius: 8px;
        color: white;
        padding: 4px 10px;
        text-align: center;
        display: inline-block;
        font-size: 18px;
        cursor: pointer;
        margin: 5px;
        font-family: monospace;
    }

    .btn-edit:hover {
        background-color: #4681f4;
    }

    .btn-stat {
        position: relative;
        background-color: #10439F;
        border-radius: 8px;
        color: white;
        padding: 8px 15px;
        font-size: 17px;
        cursor: pointer;
        font-family: monospace;
        bottom: 1.6em;
        left: 9em;
    }

    .btn-stat:hover {
        background-color: #4681f4;
    }

    p {
        text-align: right;
        padding: 0 125px;
        top: 2px;
    }

    a {
        text-align: center;
        text-decoration: none;
        margin-bottom: 10px;
    }

    span {
        font-size: 1em;
    }

    .drop {
        font-size: 17px;
        text-align: center;
        width: 150px;
        height: 34px;
        font-family: monospace;
        margin: 3px;
    }

    .total {
        background-color: #A0DEFF;
        height: 2em;
        font-weight: bold;
        color: red;
        letter-spacing: 1px;
        font-size: 1.1em;
    }
</style>

<body>
    <div>
        <?php
        include ("header.php");
        ?>

        <h1>Product Lists</h1>
        <?php $text = isset($_POST['txtsearch']) ? $_POST['txtsearch'] : null; ?>
        <?php $filterby = isset($_POST['filterby']) ? $_POST['filterby'] : null; ?>
        <div class="fieldset" align="center">
            <legend>Search</legend>
            <form method="post">
                <select class="drop" name="txtfield">
                    <option value="1">ID</option>
                    <option value="2">Model</option>
                </select>
                <input class="text" type="text" name="txtsearch" value="<?php echo ($text) ?>">
                <input class="btn-search" type="submit" name="btnsearch" value="Search" class='button'>
                <input class="btn-search" type="submit" name="btnreset" value="Reset" class='button button5'>

            </form>

        </div>

        <p>
            <a href="proAdd.php" class="btn-add"><span>+</span> Add</a><br>
        </p>

        <a href="statistic.php" class="btn-stat">Statistic</a><br>

        <div class="div-table">
            <table align="center" class="table" border="0">
                <tr>
                    <th>ProductID</th>
                    <th>Model</th>
                    <th>Make</th>
                    <th>Year</th>
                    <th>Qty</th>
                    <th>Price</th>
                    <th>Total</th>
                    <th>Image</th>
                    <th>Options</th>
                </tr>
                <?php
                require ("db.php");
                $sql = "SELECT * FROM tblproduct ";
                $totalqty = 0;
                $totalproduct = 0;
                $grandtotal = 0;
                //Search
                if (isset($_POST["btnsearch"])) {
                    $field = $_POST["txtfield"];
                    switch ($field) {
                        case '1':
                            $sql .= " where productID=?";
                            $stmt = $conn->prepare($sql);
                            $stmt->bind_param('s', $text);
                            break;
                        case '2':
                            $sql .= " WHERE model like CONCAT('%',?,'%')";
                            $stmt = $conn->prepare($sql);
                            $stmt->bind_param('s', $text);
                            break;
                    }
                } else {
                    $stmt = $conn->prepare($sql);
                }

                $stmt->execute();
                $result = $stmt->get_result();
                while ($row = $result->fetch_assoc()) {
                    $totalprice = $row['price'] * $row['qty'];
                    echo "<tr>";
                    echo "<td>" . $row["productID"] . "</td>";
                    echo "<td>" . $row["model"] . "</td>";
                    echo "<td>" . $row["make"] . "</td>";
                    echo "<td>" . $row["year"] . "</td>";
                    echo "<td>" . $row["qty"] . "</td>";
                    echo "<td>$ " . $row["price"] . "</td>";
                    echo "<td>$ " . $totalprice . "</td>";
                    echo "<td><img src='Images/" . $row["image"] . "' width='100px' height='75px'></td>";
                    echo ("<td>     
                        <a href='productEdit.php?productID=" . $row['productID'] . "' class='btn-edit'>Edit</a>
                        <a href='productDelete.php?productID=" . $row['productID'] . "' class='btn-delete' onclick='return confirm(\"Are you sure?\")'>Delete</a></td>");
                    echo ("</tr>");
                    $totalqty += $row["qty"];
                    $totalproduct += 1;
                    $grandtotal += $totalprice;
                }
                echo ("<tr class='total'><td colspan='2'>Total Product  : $totalproduct <td colspan='3' >Total Qty : $totalqty</td>
                <td td colspan='2' >Grand Total : $$grandtotal</tr>");
                ?>
            </table>
        </div>

    </div>
</body>

</html>