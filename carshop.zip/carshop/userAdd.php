<!DOCTYPE html>
<html>
<style>
    input[type=text],
    [type=date],
    [type=file],
    select,
    input[type=password] {
        width: 100%;
        padding: 12px 20px;
        margin: 8px 0;
        display: inline-block;
        border: 1px solid #ccc;
        border-radius: 4px;
        box-sizing: border-box;
    }

    input[type=submit] {
        width: 100%;
        height: 5vh;
        background-color: #45a049;
        color: white;
        padding: 11px 20px;
        margin: 8px 0;
        border: none;
        border-radius: 4px;
        cursor: pointer;
        margin-top: 0em;
    }


    input[type=submit]:hover {
        background-color: #40A578;
    }

    h1 {
        margin-top: 3em;
        font-family: monospace;
        font-size: 20;
    }

    div {
        width: 300px;
        border-radius: 5px;
        background-color: white;
        padding: 20px;
        margin: auto;
        margin-top: 0.5em;
    }

    label {
        font-family: monospace;
        font-size: 16px;
    }

    .label {
        font-family: monospace;
        font-size: 16px;
    }
</style>

<body>
    <h1 align="center">Add Account</h1>
    <div>

        <form method="post">
            <label for="fullname">FullName</label>
            <input type="text" id="fullname" name="fullname" required>
            <label for="username">Username</label>
            <input type="text" id="username" name="username" required>
            <label for="password">Password</label>
            <input type="password" id="password" name="password" required>
            <label for="cpassword">Confirm-Password</label>
            <input type="password" id="cpassword" name="cpassword" required>
            <label for="Gender">Gender</label>
            <select class="label" name="gender">
                <option>Male</option>
                <option>Female</option>
            </select>
            <label for="Email">Email</label>
            <input type="text" id="email" name="email" required>
            <label for="Phone">Phone</label>
            <input type="text" id="phone" name="phone" required>
            <input type="submit" name="btnsubmit" value="Save">
        </form>
    </div>
    <?php
    if (isset($_POST['btnsubmit'])) {
        require ("db.php");
        $fullname = $_POST["fullname"];
        $username = $_POST["username"];
        $password = $_POST["password"];
        $cpassword = $_POST["cpassword"];
        $gender = $_POST["gender"];
        $email = $_POST["email"];
        $phone = $_POST["phone"];
        if ($password != $cpassword) {
            die("password and con-password not match!!");
        }
        $sql = "INSERT INTO tbluser(fullname,username, password , gender , email , phone) VALUES(?,?,?,?,?,?);";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssssss", $fullname, $username, md5($password), $gender, $email, $phone);
        if ($stmt->execute() == true) {
            header("Location:user.php");
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    }
    ?>
    <?php
    include ("header.php");
    ?>
</body>

</html>