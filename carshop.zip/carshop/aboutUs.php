<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>About US</title>
</head>

<style>
  h1 {
    position: relative;
    margin-left: 4em;
  }

  .container {
    top: 22em;
    position: relative;
    display: flex;
  }

  .text {
    position: relative;
    bottom: 5em;
    width: 45%;
    margin-left: 4em;
  }

  .text p {
    color: black;
    text-align: justify;
  }
</style>

<body>
  <?php
  require ("headeruser.php");
  ?>
  <div class="container">
    <div>
      <h1>
        Fascination Sheer Driving Pleasure
      </h1>
    </div>
    <div class="text">
      <p>
        Lorem ipsum dolor sit amet consectetur, adipisicing elit. Impedit ut minima officia excepturi ab expedita,
        consectetur atque in a, unde tempora, consequuntur saepe repellendus corporis perferendis iure nesciunt quia.
        Nostrum velit provident veniam molestias ipsam placeat corporis asperiores sunt omnis iste ipsa at corrupti
        assumenda, et eum ullam aliquam nam est? Reprehenderit amet facilis temporibus tempore exercitationem maxime.
        Nesciunt veniam quasi doloribus vitae voluptates vero consequuntur nostrum accusamus rerum, et qui, eligendi
        blanditiis facere pariatur in corporis, fugiat odio? Repellat enim saepe vitae magni quos nesciunt tempore
        mollitia recusandae blanditiis, obcaecati ab laboriosam corrupti! Quae dolores temporibus reiciendis, impedit
        veniam beatae ab quibusdam, repellendus voluptates tenetur quis repellat voluptas accusamus ipsa, vel pariatur!
        Ducimus modi, error reprehenderit eum sunt rerum itaque architecto fuga consequatur laudantium dolorem illum
        atque. Possimus repellendus vero atque. Excepturi, commodi iste debitis inventore ad et laboriosam
        necessitatibus, neque fugit veritatis minima facilis molestias eos, provident odit.
      </p>
    </div>
  </div>
</body>

</html>