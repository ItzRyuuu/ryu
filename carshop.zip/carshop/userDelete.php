<?php
require 'db.php';
$userID = $_GET["userID"];
$sql = "delete from tbluser where userID=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $userID);
if ($stmt->execute() == true) {
    header("Location:user.php");
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}
?>