<!DOCTYPE html>
<html>

<style>
    h1 {

        text-align: center;
        margin-top: 40px;
        margin-bottom: 40px;
        font-family: monospace;
        font-size: 30px;
        margin-top: 4em;
    }

    div {

        text-align: center;
    }

    .select {
        font-size: 17px;
        text-align: center;
        width: 308px;
        height: 40px;
        font-family: monospace;
        margin-top: 5px;
        margin-bottom: 5px;
    }

    .text {
        height: 35px;
        width: 300px;
        font-size: 17px;
        text-align: center;
        font-family: monospace;
        margin-bottom: 5px;
        margin-top: 5px;
    }

    .lb1 {

        padding-right: 15.5%;
        font-family: Arial, Helvetica, sans-serif;
    }

    .lb2 {

        padding-right: 15%;
        font-family: Arial, Helvetica, sans-serif;
    }

    .lb3 {

        padding-right: 15.3%;
        font-family: Arial, Helvetica, sans-serif;
    }

    .lb4 {

        padding-right: 11.4%;
        font-family: Arial, Helvetica, sans-serif;
    }

    .lb5 {

        padding-right: 16.6%;
        font-family: Arial, Helvetica, sans-serif;
    }

    .lb6 {

        padding-right: 17%;
        font-family: Arial, Helvetica, sans-serif;
    }

    .lb7 {

        padding-right: 16.5%;
        font-family: Arial, Helvetica, sans-serif;
    }

    .cpass {
        padding-right: 11.3%;
        font-family: Arial, Helvetica, sans-serif;
    }

    .btnsave {
        background-color: #4681f4;
        border: none;
        width: 20%;
        border-radius: 8px;
        color: white;
        padding: 8px 15px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 17px;
        margin: 4px 2px;
        cursor: pointer;
        margin-top: 20px;
        font-family: monospace;
    }

    .btnsave:hover {
        background-color: #5356FF;
    }

    .drop {
        font-size: 17px;
        text-align: center;
        width: 300px;
        height: 34px;
        font-family: monospace;
        margin: 3px;
    }

    .btn-return {
        position: relative;
        background-color: transparent;
        color: black;
        text-decoration: none;
        font-size: 16.2px;
        font-family: Arial;
        cursor: pointer;
        bottom: 2em;
        margin-left: 2.5em;
    }
</style>

<body>

    <div>
        <?php
        if (!isset($_POST['btnsubmit'])) {
            require ("db.php");
            $userID = $_GET['userID'];
            $sql = "SELECT * FROM tbluser WHERE userID=?;";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("i", $userID);
            $stmt->execute();
            $result = $stmt->get_result();
            if ($row = $result->fetch_assoc()) {
                ?>
                <h1>Edit Account</h1>
                <form method="post">
                    <label class="lb1" for="fullname">Fullname</label><br>
                    <input class="text" type="text" id="fullname" name="fullname" value="<?php echo ($row['fullname']) ?>"
                        required><br>
                    <label class="lb2" for="username">Username</label><br>
                    <input class="text" type="text" id="username" name="username" value="<?php echo ($row['username']) ?>"
                        required><br>
                    <label class="lb3" for="password">Password</label><br>
                    <input class="text" type="password" id="password" name="password" required><br>
                    <label class="cpass" for="cpassword">Confirm-Password</label><br>
                    <input class="text" type="password" id="cpassword" name="cpassword" required><br>
                    <label class="lb7" for="email">Gender</label><br>
                    <select class="drop" value="gender" name="gender">
                        <option disabled selected>----Select----</option>
                        <option>Male</option>
                        <option>Female</option>
                    </select><br>
                    <label class="lb6" for="email">Email</label><br>
                    <input class="text" type="text" id="email" name="email" value="<?php echo ($row['email']) ?>" required><br>
                    <label class="lb5" for="email">Phone</label><br>
                    <input class="text" type="text" id="phone" name="phone" value="<?php echo ($row['phone']) ?>" required><br>
                    <input class="btnsave" type="submit" name="btnsubmit" value="Save"><br>
                </form>
            <?php }
        } ?>
    </div>
    <?php
    if (isset($_POST['btnsubmit'])) {
        require ("db.php");
        $userID = $_GET['userID'];
        $fullname = $_POST["fullname"];
        $username = $_POST["username"];
        $password = $_POST["password"];
        $cpassword = $_POST["cpassword"];
        $gender = $_POST["gender"];
        $email = $_POST["email"];
        $phone = $_POST["phone"];
        if ($password != $cpassword) {
            die("<p align='center' style='margin-top:10em; font-size: 2em;'>Password not match!</p><p  align='center'><a ; href='user.php'>Back</a></p>");
        }
        $sql = "update tbluser set fullname=?, username=?, password=? , gender=? , email=? , phone=? where userID=?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssssssi", $fullname, $username, md5($password), $gender, $email, $phone, $userID);
        if ($stmt->execute() == true) {
            header("Location:user.php");
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    }
    ?>
    <?php

    include ("header.php");

    ?>
</body>

</html>