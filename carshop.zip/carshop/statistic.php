<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Statistic</title>
    <link rel="stylesheet" href="../Style/style.css">
</head>
<style>
    h1 {
        margin-top: 4em;
        font-family: monospace;
        text-align: center;
        font-weight: bold;
        font-size: 30px;
    }

    .div-table {

        text-align: center;
        padding-top: 2em;
        width: 100%;
        display: table;
        position: relative;
    }

    table {

        margin-left: 8em;
        width: 80%;
        height: 150px;
        font-size: 20px;
        border-collapse: collapse;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        position: absolute;

    }

    th {

        font-family: "Courier New", Courier, monospace;
        letter-spacing: 1px;
        font-size: 20px;
        /* background-color: #5DEBD7; */
        color: black;
        height: 60px;
        padding-bottom: 5px;
        font-weight: bold;
    }

    td {

        width: 50em;
        height: 5vh;
        font-size: 17px;
        border-top: 1px solid grey
    }

    .total {
        background-color: #A0DEFF;
        height: 2em;
        font-weight: bold;
        color: red;
        letter-spacing: 1px;
    }
</style>

<body>
    <h1>Statistic</h1>
    <div class="div-table">
        <table align="center">
            <tr>
                <th>N<sup>o</sup></th>
                <th>Model</th>
                <th>Quantity</th>
                <th>Total</th>
            </tr>
            <?php
            require ("db.php");
            $sql = "select * from vstatistic";
            $stmt = $conn->prepare($sql);
            $stmt->execute();
            $result = $stmt->get_result();
            $num = 1;
            $total = 0;
            while ($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $num . "</td>";
                echo "<td>" . $row["model"] . "</td>";
                echo "<td>" . $row["Quantity"] . "</td>";
                echo "<td>$" . $row["Total"] . "</td>";
                echo "</tr>";
                $total += $row["Total"];
                $num++;
            }
            echo ("<tr class='total'><td colspan='4'>Grand Total : $$total</tr>")
                ?>
        </table>
    </div>
    <?php
    require ("header.php");
    ?>
</body>

</html>