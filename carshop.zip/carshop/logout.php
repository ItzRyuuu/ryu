<?php
//delete session
session_start();
unset($_SESSION['fullname']);
unset($_SESSION['userID']);
header("Location:login.php");
?>