<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>


<style>
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        font-family: sans-serif;
    }

    body {
        background-color: white;
        min-height: 200vh;
    }

    header {
        margin-top: 0em;
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 4.5em;
        display: flex;
        justify-content: space-between;
        align-items: center;
        z-index: 100000;
        background-color: black;
    }


    header .logo {
        position: relative;
        font-weight: 800;
        color: red;
        text-decoration: none;
        font-size: 1.5em;
        text-transform: uppercase;
        letter-spacing: 2px;
        left: 1em;
    }

    header ul {

        position: relative;
        display: flex;
        justify-content: center;
        align-items: center;

    }

    header ul li {

        position: relative;
        list-style: none;
    }

    header ul li a {

        font-family: monospace;
        position: relative;
        font-size: 16px;
        margin: 0 50px;
        right: 15.5em;
        text-decoration: none;
        letter-spacing: 1px;
        font-weight: bold;
        color: white;
        padding: 0 -2px;
    }

    ul li :hover {

        border-bottom: 5px;
        color: red;

    }

    .logout {
        background-color: red;
        width: 80px;
        border-radius: 8px;
        color: white;
        padding: 8px 12px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 18px;
        cursor: pointer;
        font-family: monospace;
        margin: 1.5em;
    }

    p {
        color: white;
    }
</style>


<header>
    <a class="logo" href="indexadmin.php">Car Shop</a>
    <ul>
        <li><a href="indexadmin.php">Home</a></li>
        <li><a href="adminOrderlist.php">Order</a></li>
        <li><a href="product.php">Product</a></li>
        <li><a href="user.php">User</a></li>
        <li><a href="admin.php">Admin</a></li>

        <a class="logout" href="logout.php">Logout</a>
    </ul>

</header>

<body>



</body>

</html>