<?php
session_start();
if (isset($_SESSION['userID'])) {
    $userID = $_SESSION['userID'];
} else {
    echo "User ID is not set in the session.";
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order list</title>
</head>

<style>
    h2 {
        margin-top: 3em;
        font-family: monospace;
        text-align: center;
        font-weight: bold;
        font-size: 30px;
    }

    .div-table {

        text-align: center;
        padding-top: 3em;
        width: 100%;
        display: table;
        position: relative;
    }

    .table {

        margin-left: 12em;
        width: 70%;
        height: 200px;
        font-size: 17px;
        border-collapse: collapse;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        position: absolute;

    }

    th {

        font-family: "Courier New", Courier, monospace;
        letter-spacing: 1px;
        font-size: 20px;
        /* background-color: #5DEBD7; */
        color: black;
        height: 50px;
        padding-bottom: 10px;
        font-weight: bold;
    }

    td {
        height: 7vh;
        border-top: 1px solid grey;
        border-bottom: 1px solid grey;
    }

    .total {
        background-color: #A0DEFF;
        height: 1.5em;
        font-weight: bold;
        color: red;
        letter-spacing: 1px;
    }

    .btn-detail {

        background-color: #4681f4;
        width: 80px;
        border-radius: 8px;
        color: white;
        padding: 6px 11px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 18px;
        cursor: pointer;
        font-family: monospace;
    }

    .btn-detail:hover {
        background-color: #5356FF;
    }
</style>

<body>
    <div>
        <h2>Order List</h2>

        <body>
            <div class="div-table">
                <?php
                require ("headeruser.php") ?>
                <table class="table" align="center">
                    <tr>
                        <th><span>&#8470;</span></th>
                        <th>Order ID</th>
                        <th>Model</th>
                        <th>Total</th>
                        <th>Option</th>
                    </tr>
                    <?php
                    require ("db.php");
                    $totalproduct = 0;
                    $total = 0;
                    $num = 0;
                    $sql = "SELECT * FROM tblorderproduct where userID=?";
                    $stmt = $conn->prepare($sql);
                    $stmt->bind_param("i", $userID);
                    $stmt->execute();
                    $result = $stmt->get_result();
                    while ($row = $result->fetch_assoc()) {
                        $num++;
                        echo "<tr>";
                        echo "<td>" . $num . "</td>";
                        echo "<td>" . $row["orderid"] . "</td>";
                        echo "<td>" . $row["model"] . "</td>";
                        echo "<td>$" . $row["price"] . "</td>";
                        echo "<td> 
                        <a href='orderdetail.php?orderid=" . $row["orderid"] . "&productID=" .
                            $row["productID"] . "' class='btn-detail'>Detail</a>
                        </td>";
                        echo "</tr>";
                        $total += $row['price'];
                        $totalproduct += 1;

                    }
                    echo ("<tr class='total'><td colspan='2'>Total Order  : $totalproduct <td><td colspan='2' style='text-right : left' >Grand Total : $$total</td></tr>");
                    ?>
                </table>
            </div>
        </body>

</html>
</div>
</body>

</html>