<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<style>
    body {
        background-image: url("15691.jpg");
        background-size: cover;
        background-position: center;
        background-color: #f8f8f8;
        background-attachment: fixed;
    }

    .form {
        margin-top: -1em;
    }

    .text {
        height: 35px;
        width: 300px;
        font-size: 20px;
        text-align: center;
        font-family: monospace;
        margin-bottom: 5px;
        margin-top: 5px;
        border-radius: 10px;
        background-color: transparent;
    }

    h1 {
        margin-bottom: 15px;
        font-size: 40px;
        font-family: Courier;
        color: black;
        text-align: center;
    }

    div {

        text-align: left;
        style=font-family: Courier New;
        font-size: 15px;
        padding-top: 30px;
        color: black;
    }

    .submitbutton {

        background-color: #00b4d8;
        /* background-color: #0D47A1; */
        color: white;
        border: 1px;
        cursor: pointer;
        text-align: center;
        width: 60%;
        height: 35px;
        border-radius: 10px;
        margin-top: 1.5em;

    }

    .submitbutton:hover {
        background-color: #0077b6;
    }

    table {
        font-size: 20px;
        width: 60px;
        height: 20px;
    }

    ::placeholder {

        color: grey;
        font-size: 15px;
    }

    ul {
        display: flex;
        justify-content: center;
    }

    ul li {

        list-style: none;

    }

    ul li a {

        font-family: monospace;
        position: relative;
        font-size: 15px;
        margin: 0 10px;
        right: 1em;
        text-decoration: none;
        letter-spacing: 1px;
        font-weight: normal;
        color: black;

    }

    a {
        top: 1em;
        display: flex;
        padding: 0 1px;
        position: relative;
    }

    .labell {
        margin-top: 1em;
        margin-right: 2em;
        font-size: 1em;
    }

    label {
        font-family: monospace;
        font-size: 16px;
    }

    .signup-div {
        display: flex;
        justify-content: center;
        align-items: center;
        height: 2vh;
    }

    .signup {
        margin-right: 3em;
        text-align: center;
        display: inline;
    }

    .signup a {
        text-decoration: none;
        color: blue;
        margin-left: 13em;
        top: -1.2em;

    }
</style>

<body>
    <div class="background">
        <div class="shape"></div>
        <div class="shape"></div>
    </div>
    <h1>Login</h1>
    <div class="form">
        <form method="post">
            <table align="center" border="0">
                <td>
                    <label for="username">Username</label><br>
                </td>
                <tr>
                    <td>
                        <input class="text" type="text" placeholder="Enter Username" id="username" name="username"
                            required><br>
                    </td>
                </tr>
                <td>
                    <label for="password">Password</label><br>
                </td>
                <tr>
                    <td>
                        <input class="text" type="password" placeholder="Enter Password" id="password" name="password"
                            required><br>
                    </td>
                </tr>
                <tr>
                    <td align="center">
                        <button class="submitbutton" name="submit">Log In</button>
                    </td>
                </tr>
            </table>
        </form>
        <?php
        if (isset($_POST["submit"])) {

            $u = $_POST['username'];
            $p = md5($_POST['password']);
            $sql = "SELECT fullname , userID FROM tbluser WHERE username=? AND password=?;";
            require ("db.php");
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ss", $u, $p);
            $stmt->execute();
            $result = $stmt->get_result();
            if ($row = $result->fetch_assoc()) {
                session_start();
                $_SESSION['fullname'] = $row['fullname'];
                $_SESSION['userID'] = $row['userID'];
                header("Location:index.php");
                exit();
            } else {
                $sql_admin = "SELECT fullname FROM tbladmin WHERE username=? AND password=?;";
                $stmt_admin = $conn->prepare($sql_admin);
                $stmt_admin->bind_param("ss", $u, $p);
                $stmt_admin->execute();
                $result_admin = $stmt_admin->get_result();
            }
            if ($row_admin = $result_admin->fetch_assoc()) {
                session_start();
                $_SESSION['fullname'] = $row_admin['fullname'];
                header("Location:indexadmin.php");
                exit();
            } else {
                echo ("<p align='center' style='color:red'>Invalid username or password!!</p>");
            }
        }
        ?>
        <div class="signup-div">
            <p class="signup">Don't have an account? <a href="signup.php">Sign up</a></p>
        </div>
    </div>


</body>

</html>