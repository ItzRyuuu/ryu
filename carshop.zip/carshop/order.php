<?php
session_start();
if (isset($_SESSION['userID'])) {
    $userID = $_SESSION['userID'];
} else {
    echo "User ID is not set in the session.";
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order List</title>
</head>

<style>
    h1 {
        margin-top: 3em;
        margin-bottom: 1em;
        text-align: center;
    }

    h2 {
        margin-bottom: 1.5em;
    }

    .card {
        width: 100%;
        height: 100%;
    }

    .card .image {
        height: 50%;
        margin-bottom: 20px;
        /* border-radius: 15px; */

    }

    .card .image img {
        width: 60%;
        object-fit: cover;
    }

    .card .caption {
        padding-left: 1em;
        text-align: left;
        line-height: 2em;
    }

    .card .caption p {
        padding-top: 7px;
        font-size: 1.1rem;
        color: black;
        text-align: ;
        font-weight: bold;
    }

    .container {
        display: flex;
        justify-content: space-around;
        margin: 4em;
    }

    .container>div {
        width: 45%;
        height: 100%;

    }

    .container .info {
        border: 1px solid grey;
        width: 50%;
        height: 65vh;
        text-align: center;
        display: grid;
        place-content: center;


    }

    input[type="text"] {
        width: 95%;
        height: 3.5em;
        padding: 10px;
        margin-bottom: 20px;
        border: 1px solid #ccc;
    }

    label {
        font-size: 14px;
    }


    .content {
        height: 95vh;
        border-radius: 0px;
        align-content: center;
        max-width: 1120px;
        margin: auto;
        background-color: white;
        box-shadow: 0 4px 25px rgba(0, 0, 0, 0.1);
    }

    .customerinfo p {
        font-size: 25px;
        font-weight: bold;
        text-align: center;
    }

    .container>div:nth-child(2) {
        text-align: center;
    }

    .container .customerinfo {}

    table {
        text-align: center;
        font-size: 1.2rem;
        border-collapse: collapse;
        border: none;
        width: 100%;
        font-weight: bold;
        height: 4em;
        margin-bottom: 1em;
    }

    table>tr>td {
        border-top: 1px solid grey;
    }

    a {
        text-decoration: none;
        font-size: 1em;
    }

    .table-total {
        height: 6em;
        border-top: 1px solid gray;
        border-bottom: 1px solid grey;
        font-weight: normal;
        font-size: 16px;
    }

    .total {
        margin-left: 1.7em;
        text-align: center;
        font-size: 20px;
        position: relative;
    }

    input[type=submit] {
        width: 95%;
        height: 5vh;
        font-size: 1em;
        background-color: #45a049;
        color: white;
        padding: 11px 20px;
        margin: 8px 0;
        border: none;
        border-radius: 4px;
        cursor: pointer;
        margin-top: 1em;
    }

    input[type=submit]:hover {
        background-color: #389f0a;
    }

    .title {
        margin-top: 3em;
        margin-bottom: 1em;
        text-align: center;
    }

    .btn-return {
        position: relative;
        background-color: transparent;
        color: black;
        text-decoration: none;
        font-size: 16.2px;
        font-family: Arial;
        cursor: pointer;
        bottom: 2em;
        margin-left: 2.5em;
    }
</style>

<body>
    <h1 class="title">Place Order</h1>
    <a class="btn-return" href="shop.php">
        < Back to Shop</a>

            <div class="content">

                <div class="container">

                    <div class="customerinfo">
                        <h2 align="center">Customer Information</h2>
                        <form method="Post" action="">
                            <label for="name">Fullname</label>
                            <input type="text" id="fullname" name="fullname" required></br>
                            <label for="email">Email</label>
                            <input type="text" id="email" name="email" required></br>
                            <label for="phone">Phone Number</label>
                            <input type="text" id="phone" name="phone" required><br />
                            <label for="city">City</label>
                            <input type="text" id="city" name="city" required></br>
                            <label for="address">Address</label>
                            <input type="text" id="address" name="address" required></br>
                            <input type="submit" name="btnsubmit" value="Place Order">
                        </form>
                    </div>
                    <div>
                        <h2>Your Order</h2>
                        <?php
                        require ("db.php");
                        $productID = $_GET["productID"];
                        $model = $_GET["model"];
                        $price = $_GET["price"];
                        $sql = "SELECT * FROM tblproduct WHERE productID = ?";
                        $stmt = $conn->prepare($sql);
                        $stmt->bind_param("i", $productID);
                        $stmt->execute();
                        $result = $stmt->get_result();

                        while ($row = $result->fetch_assoc()) {
                            //display product
                            echo "<div class='product'>";
                            echo "<div class='card'>";
                            echo "<div class='image'    >";
                            echo "<img src='Images/" . $row["image"] . "' alt=''>";
                            echo "</div>";
                            echo "<table align='center'>";
                            echo "<div class='caption'><tr>";
                            echo "<td> Model : " . $row["model"] . "</td></tr>";
                            echo "<tr>";
                            echo "<td> Price : $" . $row["price"] . "<br></td>";
                            echo "</tr>";
                            echo "</div>";
                            echo "</table>";
                            echo "<table class='table-total' align='center'>";
                            echo "<tr>";
                            echo "<td style='font-weight : 550;'>Subtotal </td>";
                            echo "<td>$" . $row["price"] . "</td>";
                            echo "</tr>";
                            echo "<tr>";
                            echo "<td style='font-weight : 550;'>Shipping </td>";
                            echo "<td style='color: green'>FREE</td>";
                            echo "</tr>";
                            echo "</table>";
                            echo "<table class='total' align='center'>";
                            echo "<td style='font-weight : bold;'>Total </td>";
                            echo "<td style='color:red'>$" . $row["price"] . "</td>";
                            echo "</table>";
                            echo "</div>";
                            echo "</div>";
                            echo "</div>";
                        }
                        ?>
                    </div>
                </div>

            </div>
            <table border="1px">
                <?php
                if (isset($_POST['btnsubmit'])) {
                    require ("db.php");

                    //Get value
                    $fullname = $_POST["fullname"];
                    $email = $_POST["email"];
                    $phone = $_POST["phone"];
                    $city = $_POST["city"];
                    $address = $_POST["address"];
                    $qty = $_GET["qty"];
                    date_default_timezone_set("Asia/Phnom_Penh");
                    $orderdate = date("Y-m-d");

                    //Insert order info
                
                    if ($qty != 0) {

                        $sql = "INSERT INTO tblorder( orderdate, fullname , email , phone , city , address , productID) VALUES(?, ?, ? , ? , ? , ? , ?)";
                        $stmt = $conn->prepare($sql);
                        $stmt->bind_param("ssssssi", $orderdate, $fullname, $email, $phone, $city, $address, $productID);
                        if ($stmt->execute() === TRUE) {

                            //Insert order product
                            $quantity = 1;
                            $orderid = $conn->insert_id;
                            $sql = "INSERT INTO tblorderproduct(orderid, productID, model, qty , price , userID) VALUES(?, ? , ? , ? , ? , ?)";
                            $stmt = $conn->prepare($sql);
                            $stmt->bind_param("iisidi", $orderid, $productID, $model, $quantity, $price, $userID);
                            $stmt->execute();
                            echo "<script>alert('Order Successful');window.location.href ='shop.php';</script>";

                            //Update new qty value
                
                            $new_qty = $qty - 1;
                            $sql_qty = "update tblproduct set qty=? where productID=?";
                            $stmt = $conn->prepare($sql_qty);
                            $stmt->bind_param("ii", $new_qty, $productID);
                            $stmt->execute();
                        } else {
                            echo "Error: " . $sql . "<br>" . $conn->error;
                        }
                    } else {
                        echo "<script>alert('Out of Stock!');window.location.href ='shop.php';</script>";
                    }
                }
                $stmt->close();
                ?>
            </table>
            </div>
            <?php
            require ("headeruser.php");
            ?>
</body>

</html>