<?php
require 'db.php';
$adminID = $_GET["adminID"];
$sql = "delete from tbladmin where adminID=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $adminID);
if ($stmt->execute() == true) {
    header("Location:admin.php");
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}
?>