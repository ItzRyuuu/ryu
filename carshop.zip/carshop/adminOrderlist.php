<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Order</title>
</head>

<style>
    h2 {
        margin-top: 4em;
        font-family: monospace;
        text-align: center;
        font-weight: bold;
        font-size: 30px;
    }

    .div-table {

        text-align: center;
        padding-top: 2.5em;
        width: 100%;
        display: table;
        position: relative;
    }

    .table {

        margin-left: 12.5em;
        width: 70%;
        height: 200px;
        font-size: 17px;
        border-collapse: collapse;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        position: absolute;

    }

    th {

        font-family: "Courier New", Courier, monospace;
        letter-spacing: 1px;
        font-size: 20px;
        /* background-color: #5DEBD7; */
        color: black;
        height: 50px;
        padding-bottom: 10px;
        font-weight: bold;
    }

    td {
        height: 7vh;
        border-top: 1px solid grey;
        border-bottom: 1px solid grey;
    }

    .total {
        background-color: #A0DEFF;
        height: 1.5em;
        font-weight: bold;
        color: red;
        letter-spacing: 1px;
    }

    .btn-detail {

        background-color: #5356FF;
        width: 80px;
        border-radius: 8px;
        color: white;
        padding: 6px 11px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 18px;
        cursor: pointer;
        font-family: monospace;
    }

    .btn-detail:hover {
        background-color: #4681f4;
    }

    .search {
        text-align: center;
        margin-left: 1em;
        margin-top: 2em;
    }

    input[type=date] {
        text-align: center;
        width: 10em;
        height: 5vh;
    }

    input[type=submit] {
        background-color: #10439F;
        width: 75px;
        border-radius: 5px;
        color: white;
        padding: 6px 9px;
        text-decoration: none;
        font-size: 17px;
        cursor: pointer;
        border: none;
        font-family: Arial, Helvetica, sans-serif;
    }

    input[type=submit]:hover {
        background-color: #4681f4;
    }
</style>

<body>
    <div>
        <h2>Order List</h2>

        <body>
            <div class="search">
                <?php
                $date1 = isset($_POST["date1"]) ? strtotime($_POST["date1"]) : strtotime(date("Y-m-d"));
                $date2 = isset($_POST["date2"]) ? strtotime($_POST["date2"]) : strtotime(date("Y-m-d"));
                ?>
                <form method="post">
                    <span style="font-weight: bold;">Search : </span>
                    <input type="date" name="date1" value="<?php echo (date("Y-m-d", $date1)) ?>">
                    To : <input type="date" name="date2" value="<?php echo (date("Y-m-d", $date2)) ?>">
                    <input type="submit" value="Search" name="btnsearch">
                    <input type="submit" name="btnreset" value="Reset">
                </form>
            </div>
            <div class="div-table">


                <table class="table" align="center">
                    <tr>
                        <th>Order ID</th>
                        <th>Order Date</th>
                        <th>Fullname</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Option</th>
                    </tr>
                    <?php
                    require ("db.php");
                    $sql = "SELECT * FROM tblorder";

                    //Search
                    if (isset($_POST["btnsearch"])) {
                        $sql .= " where orderdate between '" . date("Y-m-d", $date1) . "' and '" . date("Y-m-d", $date2) . "'";
                    }

                    $stmt = $conn->prepare($sql);
                    $stmt->execute();
                    $result = $stmt->get_result();
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . $row["orderid"] . "</td>";
                        echo "<td>" . $row["orderdate"] . "</td>";
                        echo "<td>" . $row["fullname"] . "</td>";
                        echo "<td>" . $row["email"] . "</td>";
                        echo "<td>" . $row["phone"] . "</td>";
                        echo "<td> 
                        <a href='adminOrderdetail.php?orderid=" . $row["orderid"] . "&productID=" .
                            $row["productID"] . "' class='btn-detail'>Detail</a>
                        </td>";
                        echo "</tr>";

                    }
                    ?>
                </table>
            </div>
        </body>

</html>
</div>
<?php
require ("header.php")
    ?>
</body>

</html>