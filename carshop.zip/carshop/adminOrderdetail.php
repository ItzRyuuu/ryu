<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order List</title>
</head>

<style>
    .title {
        margin-top: 3em;
        margin-bottom: 1em;
        text-align: center;
    }

    h2 {
        margin-bottom: 2em;
        text-align: center;
    }

    .card {
        width: 100%;
        height: 100%;
    }

    .card .image {
        height: 50%;
        margin-bottom: 20px;
        /* border-radius: 15px; */

    }

    .card .image img {
        width: 55%;
        object-fit: cover;
    }

    .card .caption {
        padding-left: 1em;
        text-align: left;
        line-height: 2em;
    }

    .card .caption p {
        padding-top: 7px;
        font-size: 1.1rem;
        color: black;
        text-align: ;
        font-weight: bold;
    }

    .container {
        display: flex;
        justify-content: space-around;
        margin: 4em;
    }

    .container>div {
        width: 45%;
        height: 100%;

    }

    .container .info {
        border: 1px solid grey;
        width: 50%;
        height: 65vh;
        text-align: center;
        display: grid;
        place-content: center;


    }


    .content {
        height: 85vh;
        border-radius: 0px;
        align-content: center;
        max-width: 1000px;
        margin: auto;
        padding-bottom: 2em;
        background-color: white;
        box-shadow: 0 4px 25px rgba(0, 0, 0, 0.1);
    }

    .customerinfo p {
        font-size: 25px;
        font-weight: bold;
        text-align: center;
    }

    .container>div:nth-child(2) {
        text-align: center;
    }

    table {
        text-align: center;
        font-size: 1.2rem;
        border-collapse: collapse;
        border: none;
        width: 100%;
        height: 4em;
        margin-bottom: 1em;
    }

    table>tr>td {
        border-top: 1px solid grey;
    }

    .btn-return {
        position: relative;
        background-color: transparent;
        border-radius: 8px;
        color: black;
        padding: 6px 15px;
        text-decoration: none;
        font-size: 16.2px;
        font-family: Arial;
        cursor: pointer;
        bottom: 2em;
        margin-left: 3em;
    }

    .details p {
        color: black;
        text-align: justify;
        justify-content: center;
        font-size: 16px;
        line-height: 3em;
        font-family: sans-serif;
        border-bottom: 1px solid grey;
        letter-spacing: 1px;
    }

    .id {
        font-weight: bold;
        padding-bottom: 1em;
        color: black;
        letter-spacing: 1px;
    }
</style>

<body>
    <h1 class="title">Order Details</h1>
    <a class="btn-return" href="adminOrderlist.php">
        < Back to Orders</a>
            <div class="content">
                <div class="container">
                    <div class="details">
                        <h2>Customer Details</h2>
                        <?php
                        require ("db.php");
                        $orderid = $_GET['orderid'];
                        $sql = "SELECT * FROM tblorder WHERE orderid=?;";
                        $stmt = $conn->prepare($sql);
                        $stmt->bind_param("i", $orderid);
                        $stmt->execute();
                        $result = $stmt->get_result();
                        if ($row = $result->fetch_assoc()) {
                            echo ("<p>Order ID : " . $row["orderid"] . "</p>");
                            echo ("<p>Order Date : " . $row["orderdate"] . "</p>");
                            echo ("<p>Fullname : " . $row["fullname"] . "</p>");
                            echo ("<p>Email : " . $row["email"] . "</p>");
                            echo ("<p>Phone : " . $row["phone"] . "</p>");
                            echo ("<p>City : " . $row["city"] . "</p>");
                            echo ("<p>Address : " . $row["address"] . "</p>");
                        }
                        ?>

                    </div>

                    <div>
                        <h2>Product Details</h2>
                        <?php
                        require ("db.php");
                        $productID = $_GET["productID"];
                        $sql = "SELECT * FROM tblproduct WHERE productID = ?";
                        $stmt = $conn->prepare($sql);
                        $stmt->bind_param("i", $productID);
                        $stmt->execute();
                        $result = $stmt->get_result();

                        while ($row = $result->fetch_assoc()) {

                            echo "<div class='product'>";
                            echo "<div class='card'>";
                            echo "<p class='id'>ID : " . $row["productID"] . "</p>";
                            echo "<div class='image'    >";
                            echo "<img src='Images/" . $row["image"] . "' alt=''>";
                            echo "</div>";
                            echo "<table align='center'>";
                            echo "<div class='caption'><tr>";
                            echo "<td> Model : " . $row["model"] . "</td></tr>";
                            echo "<tr>";
                            echo "<td> Price : $" . $row["price"] . "<br></td>";
                            echo "</tr>";
                            echo "</div>";
                            echo "</table>";
                            echo "</div>";
                            echo "</div>";
                            echo "</div>";
                        }
                        ?>
                    </div>


                </div>

            </div>
            <?php
            require ("header.php");
            ?>
</body>

</html>