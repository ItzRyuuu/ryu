<?php
require 'db.php';
$productID = $_GET["productID"];
$sql = "delete from tblproduct where productID=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $productID);
if ($stmt->execute() == true) {
    header("Location:product.php");
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}
?>