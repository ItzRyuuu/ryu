<!DOCTYPE html>
<html>

<style>
    h1 {

        text-align: center;
        margin-top: 40px;
        margin-bottom: 40px;
        font-family: monospace;
        font-size: 30px;
        margin-top: 4em;
    }

    div {

        text-align: center;
    }

    .select {
        font-size: 17px;
        text-align: center;
        width: 308px;
        height: 40px;
        font-family: monospace;
        margin-top: 5px;
        margin-bottom: 5px;
    }

    .text {
        height: 35px;
        width: 300px;
        font-size: 17px;
        text-align: center;
        font-family: monospace;
        margin-bottom: 5px;
        margin-top: 5px;
    }

    .lb1 {

        padding-right: 17%;
        font-family: Arial, Helvetica, sans-serif;
    }

    .lb2 {

        padding-right: 17.2%;
        font-family: Arial, Helvetica, sans-serif;
    }

    .lb3 {

        padding-right: 17.8%;
        font-family: Arial, Helvetica, sans-serif;
    }

    .lb4 {

        padding-right: 17.4%;
        font-family: Arial, Helvetica, sans-serif;
    }

    .lb5 {

        padding-right: 18.4%;
        font-family: Arial, Helvetica, sans-serif;
    }

    .lb6 {

        padding-right: 16.6%;
        font-family: Arial, Helvetica, sans-serif;
    }


    .btnsave {
        background-color: #4681f4;
        border: none;
        width: 20%;
        border-radius: 8px;
        color: white;
        padding: 8px 15px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 17px;
        margin: 4px 2px;
        cursor: pointer;
        margin-top: 20px;
        font-family: monospace;
    }

    .btnsave:hover {
        background-color: #5356FF;
    }

    .drop {
        font-size: 17px;
        text-align: center;
        width: 300px;
        height: 34px;
        font-family: monospace;
        margin: 3px;
    }

    .img {
        width: 8em;
        height: 6em;
        margin-right: 10.5em;
    }

    .imgupload {

        width: 50%;
        margin-left: 34.5em;
    }
</style>


<body>

    <div>
        <?php
        if (!isset($_POST['btnsubmit'])) {
            require ("db.php");
            $productID = $_GET['productID'];
            $sql = "SELECT * FROM tblproduct WHERE productID=?;";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("i", $productID);
            $stmt->execute();
            $result = $stmt->get_result();
            if ($row = $result->fetch_assoc()) {
                $image = "Images/" . $row['image'];
                ?>
                <h1>Edit Product</h1>
                <form method="post" enctype="multipart/form-data">
                    <label class="lb1" for="model">Model</label><br>
                    <input class="text" type="text" id="model" name="model" value="<?php echo ($row['model']) ?>" required><br>
                    <label class="lb2" for="make">Make</label><br>
                    <input class="text" type="text" id="make" name="make" value="<?php echo ($row['make']) ?>" required><br>
                    <label class="lb3" for="year">Year</label><br>
                    <input class="text" type="text" id="year" name="year" value="<?php echo ($row['year']) ?>" required><br>
                    <label class="lb4" for="price">Price</label><br>
                    <input class="text" type="text" id="price" name="price" value="<?php echo ($row['price']) ?>" required><br>
                    <label class="lb5" for="qty">Qty</label><br>
                    <input class="text" type="text" id="qty" name="qty" value="<?php echo ($row['qty']) ?>" required><br>
                    <label class="lb6" for="email">Image</label><br>
                    <img class="img" src="<?php echo $image; ?>" id="picture" name="picture" width="80px" height="80px"><br>
                    <input class="imgupload" type="file" id="myfile" name="myfile" onchange="showimg()"><br>
                    <input class="btnsave" type="submit" name="btnsubmit" value="Save"><br>
                </form>
            <?php }
        } ?>
    </div>
    <?php
    if (isset($_POST['btnsubmit'])) {
        require ("db.php");
        $productID = $_GET['productID'];
        $model = $_POST["model"];
        $make = $_POST["make"];
        $year = $_POST["year"];
        $price = $_POST["price"];
        $qty = $_POST["qty"];
        $sql = "update tblproduct set model=?, make=?, year=? , price=? , qty=? where productID=?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sssdii", $model, $make, $year, $price, $qty, $productID);
        if ($stmt->execute() == true) {
            $extension = pathinfo($_FILES['myfile']['name'], PATHINFO_EXTENSION);
            $picture = $productID . "." . $extension;
            move_uploaded_file($_FILES['myfile']['tmp_name'], "Images/$picture");
            $conn->query("update tblproduct set image='$picture' where productID=$$productID");
            header("Location:product.php");
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    }
    ?>
    <?php

    include ("header.php");

    ?>
</body>

</html>