<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
</head>

<?php
include ("header.php");
?>

<style>
    .banner {
        background: url('Images/home.jpg');
        background-size: cover;
        top: 0;
        width: 100%;
        height: 100vh;
    }

    .banner2 {
        background: url('Images/home2.jpg');
        background-size: cover;
        top: 0;
        width: 100%;
        height: 100vh;
    }

    .info {
        font-size: 17px;
        margin-top: 4.2em;
        background-color: black;

    }

    .admin {
        text-align: right;
        margin-right: 0.5em;
    }
</style>


<body>

    <div>
        <section class="banner">
            <div class="info">
                <p class="admin">
                    <?php
                    session_start();
                    if (isset($_SESSION['fullname'])) {
                        echo ("Admin : " . $_SESSION['fullname']);
                    } else {
                        header("Location:login.php");
                    }
                    ?>
                </p>
            </div>
            <div class="promote">
                <p>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ADMIN
                    <br>
                    &nbsp;&nbsp;&nbsp;&nbsp;CONTROL PANEL
                </p>
            </div>

        </section>
    </div>
    <div>
        <section class="banner2">

        </section>
    </div>

</body>

</html>