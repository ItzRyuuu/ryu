<!DOCTYPE html>
<html>
<style>
    input[type=text],
    [type=date],
    [type=file],
    select,
    input[type=password] {
        width: 100%;
        padding: 12px 20px;
        margin: 8px 0;
        display: inline-block;
        border: 1px solid #ccc;
        border-radius: 4px;
        box-sizing: border-box;
    }

    input[type=submit] {
        width: 100%;
        height: 5vh;
        background-color: #45a049;
        color: white;
        padding: 11px 20px;
        margin: 8px 0;
        border: none;
        border-radius: 4px;
        cursor: pointer;
        margin-top: 0em;
    }


    input[type=submit]:hover {
        background-color: #40A578;
    }

    h1 {
        margin-top: 2.5em;
        font-family: monospace;
        font-size: 25px;
        text-align: center;
        margin-bottom: 0.5em;
    }

    div {
        width: 300px;
        border-radius: 5px;
        background-color: white;
        padding: 20px;
        margin: auto;
        margin-top: 0.5em;
    }

    label {
        font-family: monospace;
        font-size: 16px;
    }

    .label {
        width: 100%;
        padding: 12px 20px;
        margin: 8px 0;
        display: inline-block;
        border: 1px solid #ccc;
        border-radius: 4px;
        box-sizing: border-box;
    }

    .img {
        width: 8em;
        height: 6em;
    }
</style>
<script type="text/javascript">
    function showimg() {
        //Display Image
        var input = document.getElementById("myfile");
        var fReader = new FileReader();
        fReader.readAsDataURL(input.files[0]);
        fReader.onloadend = function (event) {
            var img = document.getElementById("picture");
            img.src = event.target.result;
        }
    }
</script>

<body>
    <div>
        <h1>Add Product</h1>
        <form method="post" enctype="multipart/form-data">
            <label for="model">Model</label>
            <input type="text" id="model" name="model" required>
            <label for="make">Make</label>
            <input type="text" id="make" name="make" required>
            <label for="year">Year</label>
            <input type="text" id="year" name="year" required>
            <label for="price">Price</label><br>
            <input class="label" type="number" id="price" name="price" required><br>
            <label for="qty">Qty</label><br>
            <input class="label" type="number" id="qty" name="qty" required><br>
            <label for="picture">Picture</label><br>
            <img class="img" src="" id="picture" name="picture" width="80px" height="80px">
            <input type="file" id="myfile" name="myfile" onchange="showimg()">
            <input type="submit" name="btnsubmit" value="Save">
        </form>
    </div>
    <?php
    if (isset($_POST['btnsubmit'])) {
        require ("db.php");
        $model = $_POST["model"];
        $make = $_POST["make"];
        $year = $_POST["year"];
        $price = $_POST["price"];
        $qty = $_POST["qty"];
        $sql = "INSERT INTO tblproduct(model,make, year , price , qty) VALUES(?,?,?,?,?);";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sssdi", $model, $make, $year, $price, $qty);
        if ($stmt->execute() == true) {
            $last_id = $conn->insert_id;
            $extension = pathinfo($_FILES['myfile']['name'], PATHINFO_EXTENSION);
            $picture = $last_id . "." . $extension;
            move_uploaded_file($_FILES['myfile']['tmp_name'], "Images/$picture");
            $conn->query("update tblproduct set image='$picture' where productID=$last_id");
            header("Location:product.php");
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    }
    ?>
    <?php

    include ("header.php");

    ?>
</body>

</html>